#! /bin/bash
echo "reboot sukses" >> /root/log.txt
/sbin/shutdown -r now